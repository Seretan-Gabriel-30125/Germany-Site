import{l as o,a as r}from"../chunks/BBs4FV0R.js";export{o as load_css,r as start};
